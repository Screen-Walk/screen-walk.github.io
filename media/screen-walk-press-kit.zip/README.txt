Screen Walk press kit

Screen Walk is an iPhone app: walking tops up minutes, and the minutes buy timed breaks from the apps you choose to keep blocking.

What is in this folder
  fact-sheet.md   Facts, how it works, and short texts about the app.
  screenshots/    Eight screenshots in a generic phone frame, 1600 x 3200 px.
  screenshots/raw/  Seven of the screenshots without a frame, 1320 x 2868 px.
  icon/           The app icon at 1024 and 512 px.
  logo/           The icon with the name, 2400 x 800 px, on a dark and on a light ground.
  images/         Five images: the home page link image and four feature cards.
  videos/         Two films (MP4), a landscape hero film and a vertical one. They are not inside the zip; they sit in this folder only.

Use
  This material may be used to write about Screen Walk.

Please note
  The screenshots show the app's own demo data, not a real person's walking or break history.

Contact
  Contact details are on https://screen-walk.github.io/#support
