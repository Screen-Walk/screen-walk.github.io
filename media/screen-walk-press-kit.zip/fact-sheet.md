# Screen Walk: fact sheet

Contact: see https://screen-walk.github.io/#support

| | |
|---|---|
| Name | Screen Walk |
| What it is | An iPhone app that keeps blocking the apps and websites you choose, and gives you minutes for walking |
| Made by | One independent developer in Türkiye |
| Platform | iPhone. Portrait, and it follows the light or dark appearance of iOS |
| Minimum iOS version | iOS 15.1, as the App Store reports it |
| Language | English only |
| Requirements | Apple Screen Time access (asked in setup), Apple Health read access for steps (the app never writes to Health), and optionally Motion & Fitness for a faster live step count. Steps come from a phone in a pocket or an Apple Watch |
| Price | 7 free days, then one payment: US $9.99. Other countries see Apple's local price in the app. No subscription, nothing renews |
| Availability | iPhone App Store, https://apps.apple.com/app/id6809172291 . The App Store lists the app in the US, Türkiye, Germany, the UK, Japan and Brazil; for other countries, see the App Store |
| Site and policy | https://screen-walk.github.io/ and https://screen-walk.github.io/#privacy |
| Not for | Parental control. It is for your own use |
| Current version | 1.4.0, released in November 2026 (blocking hours). The app was first listed on 11 September 2026 |
| State | New and small. No awards, no press, no testimonials |

## How it works, in five lines

1. You choose the apps and websites that pull you in with Apple's own picker; Screen Walk keeps blocking them with Apple's Screen Time technology.
2. Walking tops up minutes on a fare card: by default 250 steps for one minute, and the pace can be set from 100 to 1,000 steps a minute.
3. To use minutes, you start a break of 5 to 60 minutes by pressing and holding the card on a reader.
4. Your apps open for the break; blocking comes back by itself when it ends, even if Screen Walk is closed. Minutes you don't use carry over into tomorrow, then drop off the card.
5. Blocking hours: blocking can run all the time (the default) or only on the days and hours you pick; outside them your apps are open, no minutes are used and walking still tops up the card. An emergency break gives 5 minutes that use no minutes (one a day by default, 0 to 3 can be chosen).

## Also in the app

Today (the card, a short log of walks and breaks, one sentence about the day), Insights (a plain verdict on the week and a simple chart), optional step and calorie goals. No streaks, no nagging notifications, no guilt.

## Descriptions

### 25 words

Screen Walk is an iPhone app that blocks apps you choose. Walking tops up minutes on a fare card; holding the card starts a break.

### 50 words

Screen Walk is an iPhone app that blocks apps and websites you choose, using Apple's Screen Time technology. Walking tops up minutes on a fare card. To start a break of 5 to 60 minutes, you hold the card on a reader. Seven free days, then one payment, no subscription.

### 100 words

Screen Walk is an iPhone app for scrolling less and walking more, without guilt. You choose the apps and websites that pull you in, and Screen Walk keeps blocking them with Apple's Screen Time technology. Walking tops up minutes on a transit-style fare card: 250 steps for one minute by default, adjustable from 100 to 1,000. To use them, you press and hold the card on a reader to start a break of 5 to 60 minutes; blocking returns by itself. Blocking hours, an emergency break, no streaks, no account, no ads. Seven free days, then one payment, no subscription.

## Questions and answers

**What does it do that a timer in Settings does not?**
You choose the apps and websites, and Screen Walk keeps blocking them with Apple's Screen Time technology. Walking tops up minutes; a break opens the apps for the minutes you pick and blocking comes back by itself, even if Screen Walk is closed.

**Who makes it?**
One independent developer in Türkiye. It is new and small, and there are no testimonials, awards or user numbers to quote.

**Why a card?**
Minutes live on a transit-style fare card that you top up by walking and hold on a reader to spend. Starting a break is a physical, deliberate gesture: you press and hold the card on the reader.

**What data leaves the phone?**
Step counts, Health data and the apps and websites you choose stay on the phone. There is no account and no ads. The app does send anonymous usage events, so it does not claim to collect nothing. The privacy policy is at https://screen-walk.github.io/#privacy .

**What if I need my apps and have no minutes?**
An emergency break gives 5 minutes that use no minutes. It is one a day by default and you can choose 0 to 3. Blocking hours also help: outside the days and hours you pick, your apps are open and no minutes are used.

**Where do the steps come from, and do I need an Apple Watch?**
Steps come from Apple Health, so a phone in a pocket counts and so does an Apple Watch. You do not need a watch. The interface is in English only.
